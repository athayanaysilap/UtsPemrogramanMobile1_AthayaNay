
import React, { useState } from 'react';
import { SafeAreaView, StatusBar } from 'react-native';

import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';

export default function App() {
  const [isLogin, setIsLogin] = useState(false);
  const [nama] = useState('Athaya Naysila Putri');

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#EDF3FF' }}>
      <StatusBar
        backgroundColor="#EDF3FF"
        barStyle="dark-content"
      />

      {isLogin ? (
        <HomeScreen
          nama={nama}
          onLogout={() => setIsLogin(false)}
        />
      ) : (
        <LoginScreen
          onLogin={() => setIsLogin(true)}
        />
      )}
    </SafeAreaView>
  );
}
