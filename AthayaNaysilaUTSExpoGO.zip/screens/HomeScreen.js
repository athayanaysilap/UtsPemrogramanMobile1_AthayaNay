import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen({ username, onLogout }) {
  const menus = [
    { title: 'Attendance', icon: 'calendar-outline', color: '#2563EB' },
    { title: 'Tugas', icon: 'book-outline', color: '#7C3AED' },
    { title: 'Jadwal', icon: 'time-outline', color: '#0891B2' },
    { title: 'Nilai', icon: 'stats-chart-outline', color: '#059669' },
  ];

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={['#071A3D', '#155EEF', '#38BDF8']}
          style={styles.header}
        >
          <View style={styles.topBar}>
            <View>
              <Text style={styles.eyebrow}>STUDENT PORTAL</Text>
              <Text style={styles.greeting}>Hello, {username}!</Text>
              <Text style={styles.subtitle}>
                Semangat menjalani aktivitas hari ini.
              </Text>
            </View>

            <Image
              source={require('../assets/profile.jpg')}
              style={styles.profile}
            />
          </View>

          <View style={styles.banner}>
            <Ionicons
              name="school-outline"
              size={34}
              color="#FFFFFF"
            />
            <View style={{ flex: 1, marginLeft: 14 }}>
              <Text style={styles.bannerTitle}>Your Dashboard</Text>
              <Text style={styles.bannerText}>
                Semua aktivitas akademik dalam satu tempat.
              </Text>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.content}>
          <Text style={styles.sectionTitle}>Menu Akademik</Text>

          <View style={styles.grid}>
            {menus.map((item) => (
              <TouchableOpacity
                key={item.title}
                style={styles.menuCard}
                activeOpacity={0.8}
                onPress={() => alert(`${item.title} dipilih`)}
              >
                <View
                  style={[
                    styles.iconBox,
                    { backgroundColor: item.color },
                  ]}
                >
                  <Ionicons
                    name={item.icon}
                    size={27}
                    color="#FFFFFF"
                  />
                </View>

                <Text style={styles.menuTitle}>{item.title}</Text>
                <Text style={styles.menuSubtitle}>
                  Lihat informasi
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.sectionTitle}>Informasi</Text>

          <View style={styles.infoCard}>
            <Ionicons
              name="notifications-outline"
              size={25}
              color="#155EEF"
            />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.infoTitle}>Tetap Produktif!</Text>
              <Text style={styles.infoText}>
                Periksa jadwal dan tugas agar tidak terlewat.
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.logoutButton}
            onPress={onLogout}
          >
            <Ionicons name="log-out-outline" size={20} color="#DC2626" />
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F7FC',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 22,
    paddingBottom: 30,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  eyebrow: {
    color: '#BFDBFE',
    fontSize: 11,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  greeting: {
    color: '#FFFFFF',
    fontSize: 25,
    fontWeight: 'bold',
    marginTop: 8,
    maxWidth: 230,
  },
  subtitle: {
    color: '#DBEAFE',
    fontSize: 12,
    marginTop: 7,
    maxWidth: 220,
  },
  profile: {
    width: 65,
    height: 65,
    borderRadius: 33,
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.17)',
    borderRadius: 18,
    padding: 18,
    marginTop: 28,
  },
  bannerTitle: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: 'bold',
  },
  bannerText: {
    color: '#DBEAFE',
    fontSize: 12,
    marginTop: 5,
    lineHeight: 18,
  },
  content: {
    padding: 22,
  },
  sectionTitle: {
    color: '#0F172A',
    fontSize: 19,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 8,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  menuCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 17,
    marginBottom: 14,
    elevation: 3,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  menuTitle: {
    color: '#0F172A',
    fontSize: 15,
    fontWeight: 'bold',
  },
  menuSubtitle: {
    color: '#64748B',
    fontSize: 11,
    marginTop: 5,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 17,
    elevation: 2,
  },
  infoTitle: {
    color: '#0F172A',
    fontWeight: 'bold',
    fontSize: 14,
  },
  infoText: {
    color: '#64748B',
    fontSize: 12,
    marginTop: 5,
    lineHeight: 18,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FEE2E2',
    padding: 15,
    borderRadius: 14,
    marginTop: 24,
    marginBottom: 20,
  },
  logoutText: {
    color: '#DC2626',
    fontWeight: 'bold',
    marginLeft: 8,
  },
});